package g1;

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {            Socket clientSocket = new Socket("localhost", 6789);

            System.out.println("\n---------------PER TERMINARE DIGITA 'termina' 4 volte di fila---------------\naltrementi inserire primo numero, operatore logico (+, -, *, /), secondo numero\ndopo ogni numero/operatore premere 'INVIO'");
            System.out.println("nei primi 3 messaggi inserire l'operazione desiderata, poi il primo numero, poi 2 volte il secondo numero\n");

            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true);
            PrintWriter outToServer2 = new PrintWriter(clientSocket.getOutputStream(), true);
            PrintWriter outToServer3 = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
            //
            String userInput1 = inFromUser.readLine();
            String operatore = inFromUser.readLine();
            String userInput2 = inFromUser.readLine();

            while ((userInput1 = inFromUser.readLine()) !=null || (userInput2 = inFromUser.readLine()) != null || (operatore = inFromUser.readLine()) !=null) {
                outToServer.println(userInput1);
                outToServer2.println(operatore);
                outToServer3.println(userInput2);

                if (userInput1.equals("termina")) {
                    break;
                }

                String serverResponse = inFromServer.readLine();
                System.out.println("Server: " + serverResponse);
            }
            
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


