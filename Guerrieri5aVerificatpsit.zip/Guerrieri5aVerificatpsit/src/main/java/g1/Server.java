package g1;

import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(6789);
            System.out.println("Server in attesa di connessioni...");
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connessione accettata da: " + clientSocket.getInetAddress());
                
                PrintWriter outToClient = new PrintWriter(clientSocket.getOutputStream(), true);

                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String userInput1 = inFromClient.readLine();
                outToClient.println("il server ha ricevuto : " + userInput1);

                BufferedReader inFromClient2 = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String operatore = inFromClient2.readLine();
                outToClient.println("il server ha ricevuto : " + operatore);

                BufferedReader inFromClient3 = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String userInput2 = inFromClient3.readLine();
                outToClient.println("il server ha ricevuto : " + userInput2);

                while ((userInput1 = inFromClient.readLine()) != null) {
                    System.out.println("Client: " + userInput1);
                    
                    float Input1 = userInput1.indexOf(userInput1);
                    float Input2 = userInput2.indexOf(userInput2);

                    if (userInput1.equals("termina") || operatore.equals("termina") || userInput2.equals("termina")) {
                        break;
                    }


                    if(operatore.equals("+")){
                        float response = Input1 + Input2;
                        outToClient.println("risposta dal server: " + response);
                    }
                    if(operatore.equals("-")){
                        float response = Input1 - Input2;
                        outToClient.println("risposta dal server: " + response);
                    }
                    if(operatore.equals("*")){
                        float response = Input1 * Input2;
                        outToClient.println("risposta dal server: " + response);
                    }
                    if(operatore.equals("/")){
                        float response = Input1 / Input2;
                        outToClient.println("risposta dal server: " + response);
                    }

                }

                serverSocket.close();
                clientSocket.close();
                System.out.println("Connessione chiusa.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
}

